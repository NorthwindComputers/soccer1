
</div><!--end panel-->

</div><!--end container-->

<img id="bottom" src="images/bottom.png" class="fix_png"/>
<div id="footer">
<div align="center">Powered by <a href="http://www.appnitro.com" style="font-size: 100%"><strong>MachForm</strong></a><br />&copy; Copyright 2007-2010 Appnitro Software</div>
</div><!--footer-->
<?php if(!empty($footer_data)){ echo $footer_data; } ?>
</body>
</html>